class LinkRanker:

     def rankLinks(self, links, score):
         return score